extern int read_bdl (FILE *fp, double jd, double *xp, double *yp, double *zp,
    char ynot[]);

/* For RCS Only -- Do Not Edit
 * @(#) $RCSfile: bdl.h,v $ $Date: 2003/03/20 08:56:31 $ $Revision: 1.1 $ $Name:  $
 */
