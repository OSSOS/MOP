#if !defined(MISC_H)
#define MISC_H

/*
 *
 * FILE: misc.h.h
 * 
 * DESCRIPTION:
 * Definitions for structures and functions used in support
 * of the matching code.  Much of this is material that appears
 * in SHIVA, the SDSS environment.
 *
 */


#define SH_SUCCESS        0          /* indicates that all went well */
#define SH_GENERIC_ERROR  1          /* indicates that error occurred */


   /* max length of lines in input files */
#define LINELEN         300          

   /* ignore any lines in input files that start with this */
#define COMMENT_CHAR   '#'     

   /* data files can have this many data columns, at most */
#define MAX_DATA_COL    20

   /* each column in the data file can have at most this many characters */
#define MAX_COL_LENGTH 50


   /*
    * little wrappers around 'malloc' and 'free' functions.
    */

void *
shMalloc(int nbytes);

void
shFree(void *vptr);

void
shError(char *format, ...);

void
shFatal(char *format, ...);

void
shDebugSet(int level);

void
shDebug(int level, char *format, ...);

   /*
    * This is a preprocessor macro, which acts like a function.  The user
    * calls it with one argument, a condition which should evaluate to
    * 0 or 1.  If it evaluates to 1, then nothing happens; but if it
    * evaluates to 0, then the program prints an error message, giving
    * location of the error, and halts execution with an error code.
    * 
    * Thus, one typically uses it to make a 'sanity check', such as
    * making sure that a pointer (which really, really should have
    * a valid value) isn't NULL:
    *
    *     fp = fopen("file", "r");
    *        ...
    *     shAssert(fp != NULL);
    *     fgets(line, LINELEN, fp);
    *        ...
    */
#define shAssert(x) if((x)!=1){fprintf(stderr,"assertion fails in file %s, line %d\n",__FILE__,__LINE__);exit(1);}
 

   /*
    * This is a generic linear transformation.  Given the measured (xm, ym)
    * and coefficients, the expected (xe, ye) is:
    *
    *       xe = a + b*xm + c*ym
    *       ye = d + e*xm + f*ym
    */

typedef struct Trans {
  int id;
  double a,b,c,d,e,f;
} TRANS;

TRANS *atTransNew(void);
void atTransDel(TRANS *trans);
void print_trans(TRANS *trans);

   /*
    * create a new s_star structure
    */

struct s_star * 
atStarNew(double x, double y, double mag);

   /*
    * read an ASCII file with a catalog of stars, and create a list
    * of s_star structures
    */
int
read_star_file(char *filename, int xcolumn, int ycolumn, int magcolumn,
               int ra_hours_col, int *num_stars, struct s_star **list);


   /*
    * little routines to support read_star_file
    */
int
is_blank(char *line);

int
get_value(char *str, double *val);




#endif    /* MISC_H */

