#if !defined(MULTI_MATCH_H)
#define MULTI_MATCH_H


   /* 
    * if this is defined, we write "premade catalog" files in a pure ASCII
    * format, which is portable and easy-to-read, but which takes a long
    * time to read.  
    *
    * If this is NOT defined, then we write "premade catalog" files in
    * a mixture of ASCII and binary, which takes much less time to read.
    */
#undef MATCH_ASCII 

#define MULTI_OUTFILE   "multi.out"


#endif   /* MULTI_MATCH_H */
