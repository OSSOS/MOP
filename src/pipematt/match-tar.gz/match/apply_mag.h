#if !defined(APPLY_MAG_H)
#define APPLY_MAG_H

   /* this indicates a "bad" value, so don't change it */
#define BAD_MAG   99.0

#endif   /* APPLY_MAG_H */
