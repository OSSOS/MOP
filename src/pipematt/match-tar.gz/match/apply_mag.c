

/*
 * <AUTO>
 * FILE: apply_mag.c
 *
 * <HTML>
 * Given 
 *    - an ASCII file consisting of a list of stars, with one line per
 *        star and multiple columns of information separated by white space
 *    - the number of the column containing a "mag" value
 *    - a mag zero point to apply, in the sense
 *
 *                   new_mag = old_mag + zero_point
 *
 * run through the data file.  For each entry, calculate the "new_mag"
 * for the star, then replace ONLY that column in the file, leaving the
 * other information in the ASCII file as-is.
 *
 * However, don't change any magnitudes which have value "BAD_MAG" --
 * leave them as-is.
 *
 * Print the results to stdout, or place them into the file given
 * by the optional "outfile" command-line argument.
 *
 * Usage: apply_mag starfile magcol zero_point [outfile=] 
 *
 * </HTML>
 * </AUTO>
 *
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "misc.h"
#include "apply_mag.h"

#undef DEBUG           /* get some of diagnostic output */


static int
proc_star_file(char *file, int magcol, double zero_point, FILE *out_fp);


#define USAGE  "usage: apply_mag starfile magcol zero_point [outfile=] "
char *progname = "apply_mag";



int
main
   (
   int argc,
   char *argv[]
   )
{ 
   char *fileA;
   int i;
   int magcol;
   double zero_point;
   char outfile[100];
   FILE *fp;

   if (argc < 4) {
      fprintf(stderr, "%s\n", USAGE);
      exit(1);
   }

   fp = stdout;

   /* parse the arguments */
   fileA = argv[1];
   if (sscanf(argv[2], "%d", &magcol) != 1) {
      shFatal("invalid argument for column for mag values");
   }
   if (sscanf(argv[3], "%lf", &zero_point) != 1) {
      shFatal("invalid argument for zero_point");
   }

   /* 
    * check for optional argument "outfile"
    */
   for (i = 4; i < argc; i++) {
      if (strncmp(argv[i], "outfile=", 8) == 0) {
         if (sscanf(argv[i] + 8, "%s", outfile) != 1) {
            shFatal("invalid argument for outfile argument");
         }
      }
      if ((fp = fopen(outfile, "w")) == NULL) {
	 shFatal("can't open file %s for output", outfile);
      }
   }

   /* now walk through the file and do the dirty work */
   if (proc_star_file(fileA, magcol, zero_point, fp) != SH_SUCCESS) {
      shError("can't process data from file %s", fileA);
      exit(1);
   }


   if (fp != stdout) {
      fclose(fp);
   }

   return(0);
}



/****************************************************************************
 * ROUTINE: proc_star_file
 *
 * walk through the given file, one line at a time.  
 *
 * If the line starts with COMMENT_CHAR, place it into the output stream.
 * If the line is completely blank, place it into the output stream.
 *
 * Otherwise, 
 *   - read in the entire line, 
 *   - figure out the "mag" value
 *   - transform the "mag" value by adding "zero_point"
 *   - print out the line, replacing the old magnitude with the new one
 *
 * RETURNS:
 *   SH_SUCCESS            if all goes well
 *   SH_GENERIC_ERROR      if not
 */

static int
proc_star_file
   (
   char *file,              /* I: name of input file with star list */
   int magcol,              /* I: position of column with mag values */
   double zero_point,       /* I: difference to be added to all mags */
   FILE *out_fp             /* I: place output into this stream */
   )
{
   char line[LINELEN];
   char col[MAX_DATA_COL + 1][MAX_COL_LENGTH + 1];
   int i, ncol;
   int last_column = -1;
   double mag, new_mag;
   FILE *in_fp;

   if ((in_fp = fopen(file, "r")) == NULL) {
      shError("proc_star_file: can't open file %s for input", file);
      return(SH_GENERIC_ERROR);
   }

   last_column = magcol;

   while (fgets(line, LINELEN, in_fp) != NULL) {

      if ((line[0] == COMMENT_CHAR) || (is_blank(line))) {
	 fprintf(out_fp, "%s\n", line);
	 continue;
      }

      ncol = sscanf(line, "%s %s %s %s %s %s %s %s %s %s", 
              &(col[0][0]), &(col[1][0]), &(col[2][0]), &(col[3][0]), 
              &(col[4][0]), &(col[5][0]), &(col[6][0]), &(col[7][0]), 
              &(col[8][0]), &(col[9][0]));
      if (last_column > ncol) {
         shError("proc_star_file: not enough entries in following line; skipping");
         shError("  %s", line);
         continue;
      }
        
      /* now read values from each column */
      if (get_value(col[magcol], &mag) != SH_SUCCESS) {
         shError("read_data_file: can't read mag value from %s; skipping", 
                  col[magcol]);
         continue;
      }

      /* 
       * add the zero_point value to the magnitude
       */
      if (mag != BAD_MAG) {
         new_mag = mag + zero_point;
      }
      else {
	 new_mag = mag;
      }

#ifdef DEBUG
      printf(" old mag = %6.3f   new mag = %6.3f \n", mag, new_mag);
#endif
      
      /* now build up the output line */
      line[0] = '\0';
      for (i = 0; i < ncol; i++) {
	 if (i == magcol) {
	    sprintf(line, "%s %6.3f", line, new_mag);
	 }
         else {
	    sprintf(line, "%s %s", line, col[i]);
	 }
      }
      fprintf(out_fp, "%s\n", line);

   }


   fclose(in_fp);
   return(SH_SUCCESS);
}
