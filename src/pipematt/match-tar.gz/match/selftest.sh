#!/bin/sh
#
# This shell script executes the "match" program on a pair
#   of test files.  It should find that 6 of the 15 items
#   in the test files do match, and 9 of 15 don't.
#

ok1="TRANS: a=-4559.111767 b=0.009065     c=13.792614    d=5918.387618  e=-13.752850   f=0.005663    "
ok2="TRANS: a=-4559.11 b=0.01    c=13.79    d=5918.37 e=-13.75  f=0.01   "

# we'll set this to 1 if we fail a test
fail=0

res=`match testA.dat 0 1 2  testB.dat 5 6 3 outfile=out \
              matchrad=3.0 trirad=0.001 nobj=40`

# check to make sure that the TRANS matches one of the acceptable answers
#   (there are more than one due to rounding errors -- I hope)
if [ "$res" = "$ok1" ]; then
  # this passes the test
  fail=0
elif [ "$res" = "$ok2" ]; then
  # this also passes test 
  fail=0
else 
  echo "match doesn't produce expected TRANS, instead produces following:"
  echo "..$res.."
  fail=1
fi

mta=`wc out.mtA | awk '{ print $1 }'`
if [ "$mta" != 6 ]; then
  fail=1
  echo "match should produce 6 lines in out.mtA, but it has $mta"
fi

mtb=`wc out.mtB | awk '{ print $1 }'`
if [ "$mtb" != 6 ]; then
  fail=1
  echo "match should produce 6 lines in out.mtB, but it has $mtb"
fi

una=`wc out.unA | awk '{ print $1 }'`
if [ "$una" != 9 ]; then
  fail=1
  echo "match should produce 9 lines in out.unA, but it has $una"
fi

unb=`wc out.unB | awk '{ print $1 }'`
if [ "$unb" != 9 ]; then
  fail=1
  echo "match should produce 9 lines in out.unB, but it has $unb"
fi

if [ "$fail" = 0 ]; then
  echo "match passes its test"
  /bin/rm out.mt[AB] out.un[AB]
else
  echo "match fails its test; leaving files out.\* for diagnosis"
fi

exit $fail

