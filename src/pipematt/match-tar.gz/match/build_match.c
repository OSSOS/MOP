

/*
 * <AUTO>
 * FILE: build_match.c
 *
 * <HTML>
 * This file contains code which converts ASCII files containing catalogs
 * of stars from the GSC, and turns them into ASCII files containing
 *
 *           a list of the brightest stars
 *           a list of triangles formed from the brightest stars
 * 
 * These output files should be much smaller than the full catalogs.
 *
 * Usage: build_match ra dec starfile1 x1 y1 mag1 outfile [nobj=]
 *
 *   where "ra" and "dec" should be given in decimal degrees.
 *
 * </HTML>
 *
 * </AUTO>
 *
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>
#include "misc.h"
#include "build_match.h"
#include "atpmatch.h"

#define DEBUG           /* get some of diagnostic output */



#define USAGE  "usage: build_match ra dec starfile1 x1 y1 mag1 outfile [nobj=]"
char *progname = "build_match";


int
main
   (
   int argc,
   char *argv[]
   )
{ 
   int i, ret;
   int numA;
   int x1col, y1col, mag1col;
   char *fileA;
   int nobj = AT_MATCH_NBRIGHT;
   char outfile[100];
   struct s_star *star_list_A;
   double ra, dec;

   if (argc < 8) {
      fprintf(stderr, "%s\n", USAGE);
      exit(1);
   }

   /* parse the arguments */
   if (sscanf(argv[1], "%lf", &ra) != 1) {
      shFatal("can't read RA from first arg %s\n", argv[1]);
   }
   if (sscanf(argv[2], "%lf", &dec) != 1) {
      shFatal("can't read Dec from second arg %s\n", argv[2]);
   }
   fileA = argv[3];
   if (sscanf(argv[4], "%d", &x1col) != 1) {
      shFatal("invalid argument for column for X values in first file");
   }
   if (sscanf(argv[5], "%d", &y1col) != 1) {
      shFatal("invalid argument for column for Y values in first file");
   }
   if (sscanf(argv[6], "%d", &mag1col) != 1) {
      shFatal("invalid argument for column for mag values in first file");
   }
   strcpy(outfile, argv[7]);

   /*
    * check for optional argument "nobj"
    */
   for (i = 8; i < argc; i++) {
      if (strncmp(argv[i], "nobj=", 5) == 0) {
         if (sscanf(argv[i] + 5, "%d", &nobj) != 1) {
            shFatal("invalid argument for nobj argument");
         }
      }
   }

   /* read information from the input file */
   if (read_star_file(fileA, x1col, y1col, mag1col, -1, 
                 &numA, &star_list_A) != SH_SUCCESS) {
      shError("can't read data from file %s", fileA);
      exit(1);
   }

   /* 
    * call the routine which sorts and prunes the star list, and 
    * calculates from it a triangle array, and writes both star and triangle
    * arrays into the output file
    */
   ret = atBuildSmallFile(ra, dec, numA, star_list_A, nobj, outfile);
   if (ret != SH_SUCCESS) {
      shError("atBuildSmallFile returns with error");
      exit(1);
   }


   return(0);
}



