

/*
 * <AUTO>
 * FILE: match.c
 *
 * <HTML>
 * This file contains the 'main' routine, which takes instructions
 * from the user, reads information from files, calls the matching
 * routines, and writes information back onto disk.
 *
 * Usage: match starfile1 x1 y1 mag1 starfile2 x2 y2 mag2 
 *                [outfile=] [trirad=X] [nobj=N] [matchrad] [transonly]
 *
 * </HTML>
 *
 *
 *  7/18/96   - Added transonly option.  MWR
 *
 * </AUTO>
 *
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "misc.h"
#include "match.h"
#include "atpmatch.h"

#undef DEBUG           /* get some of diagnostic output */



#define USAGE  "usage: match starfile1 x1 y1 mag1 starfile2 x2 y2 mag2 "\
               " [outfile=] [trirad=X] [nobj=N] [matchrad] [transonly]"
char *progname = "match";



int
main
   (
   int argc,
   char *argv[]
   )
{ 
   int i, ret;
   int numA, numB;
   int x1col, y1col, mag1col;
   int x2col, y2col, mag2col;
   char *fileA, *fileB;
   double triangle_radius = AT_TRIANGLE_RADIUS;  /* in triangle-space coords */
   double match_radius = AT_MATCH_RADIUS;        /* in units of list B */
   double scale = -1.0;                          
   int nobj = AT_MATCH_NBRIGHT;
   int transonly = 0;                           /* if 1, only find TRANS */
   char outfile[100];
   struct s_star *star_list_A, *star_list_B;
   TRANS trans;

   if (argc < 8) {
      fprintf(stderr, "%s\n", USAGE);
      exit(1);
   }

   strcpy(outfile, AT_MATCH_OUTFILE);

   /* parse the arguments */
   fileA = argv[1];
   if (sscanf(argv[2], "%d", &x1col) != 1) {
      shFatal("invalid argument for column for X values in first file");
   }
   if (sscanf(argv[3], "%d", &y1col) != 1) {
      shFatal("invalid argument for column for Y values in first file");
   }
   if (sscanf(argv[4], "%d", &mag1col) != 1) {
      shFatal("invalid argument for column for mag values in first file");
   }
   fileB = argv[5];
   if (sscanf(argv[6], "%d", &x2col) != 1) {
      shFatal("invalid argument for column for X values in second file");
   }
   if (sscanf(argv[7], "%d", &y2col) != 1) {
      shFatal("invalid argument for column for Y values in second file");
   }
   if (sscanf(argv[8], "%d", &mag2col) != 1) {
      shFatal("invalid argument for column for mag values in second file");
   }

   /* 
    * check for optional arguments "nobj", "trirad", "outfile", "matchrad"
    *         "transonly"
    */
   for (i = 9; i < argc; i++) {
      if (strncmp(argv[i], "nobj=", 5) == 0) {
         if (sscanf(argv[i] + 5, "%d", &nobj) != 1) {
            shFatal("invalid argument for nobj argument");
         }
      }
      if (strncmp(argv[i], "trirad=", 7) == 0) {
         if (sscanf(argv[i] + 7, "%lf", &triangle_radius) != 1) {
            shFatal("invalid argument for trirad argument");
         }
      }
      if (strncmp(argv[i], "matchrad=", 9) == 0) {
         if (sscanf(argv[i] + 9, "%lf", &match_radius) != 1) {
            shFatal("invalid argument for matchrad argument");
         }
      }
      if (strncmp(argv[i], "scale=", 6) == 0) {
         if (sscanf(argv[i] + 6, "%lf", &scale) != 1) {
            shFatal("invalid argument for scale argument");
         }
      }
      if (strncmp(argv[i], "outfile=", 8) == 0) {
         if (sscanf(argv[i] + 8, "%s", outfile) != 1) {
            shFatal("invalid argument for outfile argument");
         }
      }
      if (strncmp(argv[i], "transonly", 9) == 0) {
         transonly = 1;
      }
   }

   /* read information from the first file */
   if (read_star_file(fileA, x1col, y1col, mag1col, -1, 
                 &numA, &star_list_A) != SH_SUCCESS) {
      shError("can't read data from file %s", fileA);
      exit(1);
   }

   /* read information from the second file */
   if (read_star_file(fileB, x2col, y2col, mag2col, -1, 
                 &numB, &star_list_B) != SH_SUCCESS) {
      shError("can't read data from file %s", fileB);
      exit(1);
   }

   /* call the matching routines */
   ret = atFindTrans(numA, star_list_A, numB, star_list_B,
                triangle_radius, nobj, scale, &trans);

   /*
    * if the "transonly" flag is set, stop at this point
    */
   if (transonly == 1) {
      return(0);
   }
      

   /* 
    * having found the TRANS that takes A -> B, let us apply
    * it to all the elements in A; thus, we'll have two sets of
    * of stars, each in the same coordinate system
    */
   atApplyTrans(numA, star_list_A, &trans);

   /* 
    * now match up the two sets of items, and find four subsets:
    *
    *     those from list A that do     have matches in list B
    *     those from list B that do     have matches in list A
    *     those from list A that do NOT have matches in list B
    *     those from list B that do NOT have matches in list A
    * 
    */
   atMatchLists(numA, star_list_A, numB, star_list_B, 
                match_radius, outfile);



   return(0);
}



