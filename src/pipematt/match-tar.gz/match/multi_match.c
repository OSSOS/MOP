

/*
 * <AUTO>
 * FILE: multi_match.c
 *
 * <HTML>
 * This file attempts to match a given list of detected stars against
 * a number of existing "pre-made catalog" files, where a "pre-made"
 * catalog file is a mixed ASCII/binary file with form
 *
 *   ASCII:
 *        RA Dec       (both in decimal degrees)
 *        number_of_stars
 *        list of number_of_stars star (one per line)
 *        number_of_triangles
 *   BINARY:
 *        dump of triangle structures
 * 
 * which was created with the "build_match" program.  
 *
 * Each "pre-made catalog" file should have a name like
 *
 *                prefix.0
 *                prefix.1
 *                prefix.2
 *                   ...
 *                prefix.N
 *
 * The idea is that we don't know where the telescope was pointing when
 * it saw the detected stars, so we have to check many possible catalog
 * files to find the one which matches the detected stars best.
 *
 * Usage: multi_match starfile1 x1 y1 mag1 prefix
 *               [outfile=] [trirad=X] [nobj=N] [matchrad] [transonly] 
 *               [scale=]
 *
 * </HTML>
 *
 * </AUTO>
 *
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "misc.h"
#include "multi_match.h"
#include "atpmatch.h"

#undef DEBUG           /* get some of diagnostic output */



#define USAGE  "usage: multi_match starfile1 x1 y1 mag1 prefix"\
               " [outfile=] [trirad=X] [nobj=N] [matchrad] [transonly]"\
               " [scale=]"
char *progname = "match";

static int read_premade_file(FILE *fp, double *ra, double *dec,
                             int *num_stars, struct s_star **s_array,
                             int *num_triangles, struct s_triangle **t_array);


int
main
   (
   int argc,
   char *argv[]
   )
{ 
   int i, j;
   int numA, numB;
   int num_triangles;
   int x1col, y1col, mag1col;
   int ntop, *top_votes;
   int sum, max_votes;
   char fileA[100], fileB[100];
   char best_file[100];
   double triangle_radius = AT_TRIANGLE_RADIUS;  /* in triangle-space coords */
   double match_radius = AT_MATCH_RADIUS;        /* in units of list B */
   double scale = -1.0;
   double ra, dec;
   double best_ra, best_dec;
   int nobj = AT_MATCH_NBRIGHT;
   int transonly = 0;                           /* if 1, only find TRANS */
   char prefix[100], outfile[100];
   struct s_star *star_list_A, *star_array_B;
   struct s_triangle *triangle_array_B;
   TRANS trans, best_trans;
   FILE *fp;

   if (argc < 5) {
      fprintf(stderr, "%s\n", USAGE);
      exit(1);
   }

   strcpy(outfile, MULTI_OUTFILE);

   /* parse the arguments */
   strcpy(fileA, argv[1]);
   if (sscanf(argv[2], "%d", &x1col) != 1) {
      shFatal("invalid argument for column for X values in first file");
   }
   if (sscanf(argv[3], "%d", &y1col) != 1) {
      shFatal("invalid argument for column for Y values in first file");
   }
   if (sscanf(argv[4], "%d", &mag1col) != 1) {
      shFatal("invalid argument for column for mag values in first file");
   }
   strcpy(prefix, argv[5]);

   /* 
    * check for optional arguments "nobj", "trirad", "outfile", "matchrad"
    *         "transonly"
    */
   for (i = 6; i < argc; i++) {
      if (strncmp(argv[i], "nobj=", 5) == 0) {
         if (sscanf(argv[i] + 5, "%d", &nobj) != 1) {
            shFatal("invalid argument for nobj argument");
         }
      }
      if (strncmp(argv[i], "trirad=", 7) == 0) {
         if (sscanf(argv[i] + 7, "%lf", &triangle_radius) != 1) {
            shFatal("invalid argument for trirad argument");
         }
      }
      if (strncmp(argv[i], "matchrad=", 9) == 0) {
         if (sscanf(argv[i] + 9, "%lf", &match_radius) != 1) {
            shFatal("invalid argument for matchrad argument");
         }
      }
      if (strncmp(argv[i], "outfile=", 8) == 0) {
         if (sscanf(argv[i] + 8, "%s", outfile) != 1) {
            shFatal("invalid argument for outfile argument");
         }
      }
      if (strncmp(argv[i], "scale=", 6) == 0) {
         if (sscanf(argv[i] + 6, "%lf", &scale) != 1) {
            shFatal("invalid argument for scale argument");
         }
      }
      if (strncmp(argv[i], "transonly", 9) == 0) {
         transonly = 1;
      }
   }

   /* read information from the first file */
   if (read_star_file(fileA, x1col, y1col, mag1col, -1, 
                 &numA, &star_list_A) != SH_SUCCESS) {
      shError("can't read data from file %s", fileA);
      exit(1);
   }

   /*
    * for every file we can find with a name "prefix.N", where N is
    * an integer (and we start counting at 0), read in a array of
    * stars and an array of triangles.
    */
   for (i = 0; ; i++) {
      sprintf(fileB, "%s.%d", prefix, i);
      if ((fp = fopen(fileB, "r")) == NULL) {
#ifdef DEBUG
	 printf("couldn't find file %s\n", fileB);
#endif
	 break;
      }
      else {
	 printf("reading file %s\r", fileB);
         if (read_premade_file(fp, &ra, &dec, 
                               &numB, &star_array_B, &num_triangles, 
                               &triangle_array_B) != SH_SUCCESS) {
	    shFatal("read_premade_file fails on file %s\n", fileB);
	 }
#ifdef DEBUG
	 printf("   read %4d stars and %6d triangles \n", numB, num_triangles);
#endif

	 /* must process file here */
         if (atSmallTrans(numA, star_list_A, numB, star_array_B, 
	                  num_triangles, triangle_array_B, 
	                  triangle_radius, nobj, scale,
                          &trans, &ntop, &top_votes) != SH_SUCCESS) {
#ifdef DEBUG
	    printf("   file %s doesn't yield a good TRANS\n", fileB);
#endif
	 }
	 else {
	    /* 
	     * Evaluate results of match here.  Let's just add up the
	     * votes of the top 5 vote-getters, and pick the maximum
	     * value as indicating a match.
	     */
	    sum = 0;
	    for (j = 0; (j < ntop) && (j < 5); j++) {
	       sum += top_votes[j];
	    }
	    if (sum > max_votes) {
	       max_votes = sum;
	       best_trans = trans;
	       strcpy(best_file, fileB);
	       best_ra = ra;
	       best_dec = dec;
#ifdef DEBUG
	       printf("   new best match: file %s yields %d votes\n", 
	   	     fileB, max_votes);
#endif
	    }
	    else {
#ifdef DEBUG
	       printf("   file %s isn't better, only %d votes\n", 
		        fileB, sum);
#endif
	    }
	 }

	 /* and must free up the memory here */
	 shFree(star_array_B);
	 shFree(triangle_array_B);
	 fclose(fp);
      }

   }

#ifdef DEBUG
   printf("best file %s yields %d votes: %lf %lf \n", best_file, max_votes,
	    best_ra, best_dec);
#endif

   printf("\n %d %f %f \n", max_votes, best_ra, best_dec);

   /* we were able to read from (i-1) pre-made catalog files */

   return(0);
}



/**************************************************************************
 * ROUTINE: read_premade_file
 *
 * Read in the contents of a pre-made catalog file, which is assumed to
 * have a format which is a mixture of ASCII and binary data.
 * We use a format which is ASCII at first, but turns to binary at the end:
 *
 * ASCII section:
 *   line 1         RA Dec     (in decimal degrees)
 *   line 2         nstar                          
 *   line 3         info on star 1
 *   line 4         info on star 2
 *                      ...
 *   line nstar+2   info on star nstar
 *   line nstar+3   ntriangle
 *
 * BINARY section:
 *                  binary dump of triangle 1
 *                  binary dump of triangle 2
 *                      ...
 *
 * 
 * Create an array of s_star structures, and an array of s_triangle
 * structures.  Fill the arrays with information from the file.
 * Return the arrays, and the number of elements in each, in the
 * output arguments.
 *
 * RETURNS:
 *   SH_SUCCESS         if all goes well
 *   SH_GENERIC_ERROR   if not
 */
 
static int
read_premade_file
   (
   FILE *fp,                   /* I: file pointer -- already fopen'ed */
   double *ra,                 /* O: Right Ascension of field, in dec degrees */
   double *dec,                /* O: Declination of field, in dec degrees */
   int *num_stars,             /* O: number of stars in output array */
   struct s_star **s_array,    /* O: pointer to output array of stars */
   int *num_triangles,         /* O: number of triangles in output array */
   struct s_triangle **t_array /* O: pointer to output array of triangles */
   )
{
   int i, nstar, ntriangle;
   int id, dummy;
   double x, y, mag;
#ifdef MATCH_ASCII
   double a_length, ba, ca;
   int a_index, b_index, c_index;
#endif
   struct s_star *stars;
   struct s_triangle *triangles;
   char line[LINELEN+1];

   /*
    * read in the central Ra, Dec of the field; both are in decimal degrees,
    * in J2000 coords
    */
   if (fgets(line, LINELEN, fp) == NULL) {
      shError("read_premade_file: can't read line with RA Dec");
      return(SH_GENERIC_ERROR);
   }
   if (sscanf(line, "%lf %lf", ra, dec) != 2) {
      shError("read_premade_file: can't read RA Dec from line:\n%s", 
		  line);
      return(SH_GENERIC_ERROR);
   }
   

   /*
    * First, we deal with the stars -- then, we'll read the triangles 
    */

   /* read in the number of stars */
   if (fgets(line, LINELEN, fp) == NULL) {
      shError("read_premade_file: can't read line with number of stars");
      return(SH_GENERIC_ERROR);
   }
   if (sscanf(line, "%d", &nstar) != 1) {
      shError("read_premade_file: can't read number of stars from line:\n%s", 
		  line);
      return(SH_GENERIC_ERROR);
   }

   /* now create an array, and fill it, one line at a time */
   stars = shMalloc(nstar*sizeof(struct s_star));
   for (i = 0; i < nstar; i++) {
      if (fgets(line, LINELEN, fp) == NULL) {
         shError("read_premade_file: can't read line for star %d", i);
	 shFree(stars);
         return(SH_GENERIC_ERROR);
      }
      if (sscanf(line, "%d %d %lf %lf %lf", &id, &dummy, &x, &y, &mag) != 5) {
         shError("read_premade_file: can't read star from line %d:\n%s", 
		  i, line);
	 shFree(stars);
         return(SH_GENERIC_ERROR);
      }
      stars[i].id = id;
      stars[i].index = id;
      stars[i].x = x;
      stars[i].y = y;
      stars[i].mag = mag;
      stars[i].match_id = -1;
      stars[i].next = NULL;
   }

   /* read in the number of triangles */
   if (fgets(line, LINELEN, fp) == NULL) {
      shError("read_premade_file: can't read line with number of triangles");
      shFree(stars);
      return(SH_GENERIC_ERROR);
   }
   if (sscanf(line, "%d", &ntriangle) != 1) {
      shError("read_premade_file: can't read num of triangles from line:\n%s", 
		  line);
      shFree(stars);
      return(SH_GENERIC_ERROR);
   }

   /* now create an array of triangles, and fill it, one line at a time */
   triangles = shMalloc(ntriangle*sizeof(struct s_triangle));
   for (i = 0; i < ntriangle; i++) {

#ifdef MATCH_ASCII
      /* this old version writes ASCII, one line per triangle */
      if (fgets(line, LINELEN, fp) == NULL) {
         shError("read_premade_file: can't read line for triangle %d", i);
         shFree(stars);
         shFree(triangles);
         return(SH_GENERIC_ERROR);
      }
      if (sscanf(line, "%d %d %lf %lf %lf %d %d %d", &id, &dummy, &a_length, 
                        &ba, &ca, &a_index, &b_index, &c_index) != 8) {
         shError("read_premade_file: can't read triangle from line %d:\n%s", 
		  i, line);
         shFree(stars);
         shFree(triangles);
         return(SH_GENERIC_ERROR);
      }
      triangles[i].id = id;
      triangles[i].index = id;
      triangles[i].a_length = a_length;
      triangles[i].ba = ba;
      triangles[i].ca = ca;
      triangles[i].a_index = a_index;
      triangles[i].b_index = b_index;
      triangles[i].c_index = c_index;
      triangles[i].match_id = -1;
      triangles[i].next = NULL;
#else
      /* this new version write binary dump of each triangle structure */
      if (fread((void *)&(triangles[i]), sizeof(struct s_triangle), 
		     1, fp) != 1) {
         shError("read_premade_file: can't read triangle from line %d:\n%s", 
		  i, line);
         shFree(stars);
         shFree(triangles);
         return(SH_GENERIC_ERROR);
      }
#endif
   }

   /* set the output arguments */
   *num_stars = nstar;
   *s_array = stars;
   *num_triangles = ntriangle;
   *t_array = triangles;

   return(SH_SUCCESS);
}
