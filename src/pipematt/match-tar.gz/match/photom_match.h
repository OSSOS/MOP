#if !defined(PHOTOM_MATCH_H)
#define PHOTOM_MATCH_H

   /* 
    * this value denotes a "bad" magnitude measurement -- do not
    * include it in any computations.
    */
#define BAD_MAG        99.0

   /* there can be at most this many passbands defined in each file */
#define MAX_PASSBANDS  10

   /* default radius for two stars to match is 10 arcseconds */
#define MATCH_RADIUS   10.0

   /* multiply by this to convert degrees to radians */
#ifndef PI
#define PI 3.14159265359
#endif
#define DEGTORAD  (PI/180.0)

   /* this structure contains a number of magnitudes for a single star */
typedef struct s_mstar {
   int id;              /* used for internal debugging only */
   double ra;           /* Right Ascension of star, J2000 */
   double dec;          /* Declination of star, J2000 */
   double mag[MAX_PASSBANDS];   /* magnitude of star in several passbands */
   int match_id;        /* matching star in other list */
} s_mstar;


#endif   /* PHOTOM_MATCH_H */
