

/*
 * <AUTO>
 * FILE: apply_match.c
 *
 * <HTML>
 * Given 
 *    - an ASCII file consisting of a list of stars, with one line per
 *        star and multiple columns of information separated by white space
 *    - the numbers of the columns containing "X" and "Y" coords of stars
 *    - a central RA and Dec, each in decimal degrees
 *    - coefficients of a TRANS structure which convert "X" and "Y"
 *        coordinates from the ASCII file's system to arcseconds of RA and Dec,
 *        centered on the central RA and Dec,
 *
 * run through the data file.  For each entry, calculate the (RA, Dec) of
 * the star, then replace the "X" and "Y" values with (RA, Dec).  Leave all
 * other information in the ASCII file as-is.
 *
 * The TRANS structure converts "X" and "Y" to "delta_ra" and "delta_dec" via
 *
 *       delta_ra  = a + b*x + c*y
 *       delta_dec = d + e*x * c*y
 *
 * where "delta_ra" and "delta_dec" are in arcseconds, and measure the distance
 * of the star from the center of field from which the TRANS was calculated.
 * We assume that the given "ra" and "dec" values are the same as this
 * central position.
 *
 * We force all values of RA to lie between 0 < RA < 360
 *
 * Print the results to stdout, or place them into the file given
 * by the optional "outfile" command-line argument.
 *
 * Usage: apply_match starfile1 xcol ycol ra dec a b c d e f [outfile=] 
 *
 * </HTML>
 * </AUTO>
 *
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "misc.h"
#include "apply_match.h"

#undef DEBUG           /* get some of diagnostic output */


static int
proc_star_file(char *file, int xcol, int ycol, double ra, double dec,
               TRANS *trans, FILE *out_fp);


#define USAGE  "usage: apply_match starfile1 xcol ycol ra dec a b c d e f"\
               " [outfile=] "
char *progname = "apply_match";



int
main
   (
   int argc,
   char *argv[]
   )
{ 
   char *fileA;
   int i;
   int xcol, ycol;
   double ra, dec;
   double a, b, c, d, e, f;
   char outfile[100];
   FILE *fp;
   TRANS trans;

   if (argc < 12) {
      fprintf(stderr, "%s\n", USAGE);
      exit(1);
   }

   fp = stdout;

   /* parse the arguments */
   fileA = argv[1];
   if (sscanf(argv[2], "%d", &xcol) != 1) {
      shFatal("invalid argument for column for X values in first file");
   }
   if (sscanf(argv[3], "%d", &ycol) != 1) {
      shFatal("invalid argument for column for Y values in first file");
   }
   if (sscanf(argv[4], "%lf", &ra) != 1) {
      shFatal("invalid argument for RA");
   }
   if (sscanf(argv[5], "%lf", &dec) != 1) {
      shFatal("invalid argument for Dec");
   }
   if (sscanf(argv[6], "%lf", &a) != 1) {
      shFatal("invalid argument for TRANS coefficient A");
   }
   if (sscanf(argv[7], "%lf", &b) != 1) {
      shFatal("invalid argument for TRANS coefficient B");
   }
   if (sscanf(argv[8], "%lf", &c) != 1) {
      shFatal("invalid argument for TRANS coefficient C");
   }
   if (sscanf(argv[9], "%lf", &d) != 1) {
      shFatal("invalid argument for TRANS coefficient D");
   }
   if (sscanf(argv[10], "%lf", &e) != 1) {
      shFatal("invalid argument for TRANS coefficient E");
   }
   if (sscanf(argv[11], "%lf", &f) != 1) {
      shFatal("invalid argument for TRANS coefficient F");
   }

   /* 
    * check for optional argument "outfile"
    */
   for (i = 12; i < argc; i++) {
      if (strncmp(argv[i], "outfile=", 8) == 0) {
         if (sscanf(argv[i] + 8, "%s", outfile) != 1) {
            shFatal("invalid argument for outfile argument");
         }
      }
      if ((fp = fopen(outfile, "w")) == NULL) {
	 shFatal("can't open file %s for output", outfile);
      }
   }

   /* create a TRANS structure from the given coefficients */
   trans.a = a;
   trans.b = b;
   trans.c = c;
   trans.d = d;
   trans.e = e;
   trans.f = f;

   /* now walk through the file and do the dirty work */
   if (proc_star_file(fileA, xcol, ycol, ra, dec, &trans, fp) != SH_SUCCESS) {
      shError("can't process data from file %s", fileA);
      exit(1);
   }


   if (fp != stdout) {
      fclose(fp);
   }

   return(0);
}



/****************************************************************************
 * ROUTINE: proc_star_file
 *
 * walk through the given file, one line at a time.  
 *
 * If the line starts with COMMENT_CHAR, place it into the output stream.
 * If the line is completely blank, place it into the output stream.
 *
 * Otherwise, 
 *   - read in the entire line, 
 *   - figure out the "X" and "Y" coords
 *   - transform the "X" and "Y" coords to be (RA, Dec) from the central
 *         "ra" and "dec", in units of arcseconds
 *   - transform from the tangent plane back to the spherical sky, so that
 *         we have genuine (RA, Dec) for each star
 *   - print out the line, replacing the "X" with RA, the "Y" with Dec
 *
 * RETURNS:
 *   SH_SUCCESS            if all goes well
 *   SH_GENERIC_ERROR      if not
 */

static int
proc_star_file
   (
   char *file,              /* I: name of input file with star list */
   int xcol,                /* I: position of column with X positions */
   int ycol,                /* I: position of column with Y positions */
   double ra,               /* I: central RA of tangent plane (degrees) */
   double dec,              /* I: central Dec of tangent plane (degrees) */
   TRANS *trans,            /* I: TRANS taking (x,y) -> (ra, dec) */
   FILE *out_fp             /* I: place output into this stream */
   )
{
   char line[LINELEN];
   char col[MAX_DATA_COL + 1][MAX_COL_LENGTH + 1];
   int i, ncol;
   int last_column = -1;
   double xval, yval;
   double r_ra, r_dec;
   double z, alpha, delta;
   double delta_ra, delta_dec;
   FILE *in_fp;

   if ((in_fp = fopen(file, "r")) == NULL) {
      shError("proc_star_file: can't open file %s for input", file);
      return(SH_GENERIC_ERROR);
   }

   last_column = (xcol > ycol ? xcol : ycol);
   r_ra = ra*DEGTORAD;
   r_dec = dec*DEGTORAD;

   while (fgets(line, LINELEN, in_fp) != NULL) {

      if (line[0] == COMMENT_CHAR) {
	 continue;
      }
      if (is_blank(line)) {
	 continue;
      }

      ncol = sscanf(line, "%s %s %s %s %s %s %s %s %s %s", 
              &(col[0][0]), &(col[1][0]), &(col[2][0]), &(col[3][0]), 
              &(col[4][0]), &(col[5][0]), &(col[6][0]), &(col[7][0]), 
              &(col[8][0]), &(col[9][0]));
      if (last_column > ncol) {
         shError("proc_star_file: not enough entries in following line; skipping");
         shError("  %s", line);
         continue;
      }
        
      /* now read values from each column */
      if (get_value(col[xcol], &xval) != SH_SUCCESS) {
         shError("read_data_file: can't read X value from %s; skipping", 
                  col[xcol]);
         continue;
      }
      if (get_value(col[ycol], &yval) != SH_SUCCESS) {
         shError("read_data_file: can't read Y value from %s; skipping", 
                  col[ycol]);
         continue;
      }


      /* 
       * let's transform from (x,y) to (delta_ra, delta_dec) using the TRANS 
       */
      delta_ra  = trans->a + trans->b*xval + trans->c*yval;
      delta_dec = trans->d + trans->e*xval + trans->f*yval;

      /*
       * and now convert from arcseconds to radians 
       * (convenient for calculations) 
       */
      delta_ra = (delta_ra/3600.0)*DEGTORAD;
      delta_dec = (delta_dec/3600.0)*DEGTORAD;

      /* 
       * we have (delta_ra, delta_dec), in radians; these give the distance
       * of this star from the central (RA, Dec).  Now we can de-project from
       * the tangent plane (centered on RA,Dec) and calculate the actual
       * RA, Dec of the star (in degrees)
       */
      z = cos(r_dec) - delta_dec*sin(r_dec);

      alpha = atan(delta_ra/z)/DEGTORAD;
      alpha = alpha + ra;

      delta = cos((alpha - ra)*DEGTORAD)*(sin(r_dec) + delta_dec*cos(r_dec))/z;
      delta = atan(delta)/DEGTORAD;

      /*
       * make sure new RA lies in range  0 < RA < 360
       */
      if (alpha < 0) {
	 alpha += 360.0;
      } 
      if (alpha >= 360.0) {
	 alpha -= 360.0;
      }

#ifdef DEBUG
      printf(" new RA = %10.5f,   new dec = %10.5f\n", alpha, delta);
#endif
      
      /* now build up the output line */
      line[0] = '\0';
      for (i = 0; i < ncol; i++) {
	 if (i == xcol) {
	    sprintf(line, "%s %10.5f", line, alpha);
	 }
	 else if (i == ycol) {
	    sprintf(line, "%s %10.5f", line, delta);
	 } 
         else {
	    sprintf(line, "%s %s", line, col[i]);
	 }
      }
      fprintf(out_fp, "%s\n", line);

   }



   fclose(in_fp);
   return(SH_SUCCESS);
}
