#if !defined(BUILD_MATCH_H)
#define BUILD_MATCH_H

   /* ignore any lines in input files that start with this */
#define COMMENT_CHAR   '#'     

   /* data files can have this many data columns, at most */
#define MAX_DATA_COL    10

   /* each column in the data file can have at most this many characters */
#define MAX_COL_LENGTH 50

#endif   /* BUILD_MATCH_H */
