#if !defined(PRECESS_H)
#define PRECESS_H


void
from_j2000(double equinox, double oldra, double olddec, 
           double *newra, double *newdec);

void
to_j2000(double equinox, double oldra, double olddec, 
         double *newra, double *newdec);

#endif
