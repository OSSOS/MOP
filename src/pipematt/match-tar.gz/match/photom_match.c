

/*
 * <AUTO>
 * FILE: photom_match.c
 *
 * <HTML>
 * Given 
 *    - an ASCII file consisting of a "raw" list of stars, with one line per
 *        star and multiple columns of information separated by white space
 *    - the numbers of the columns containing "RA" and "Dec" coords of stars
 *        (assumed to be in decimal degrees) 
 *    - equinox of the coordinates of this "raw" starlist
 *    - a set of passband-column pairs, of the form
 *                  U=4 B=5 V=3 
 *        which give the names of passbands in the "raw" list, plus the columns
 *        in which each passband is to be found
 *    - an ASCII file containing a catalog of standard stars, also in 
 *        multicolumn format
 *    - the numbers of columns containing "RA" and "Dec" coords of stars
 *        (assumed to be in decimal degrees) for the catalog
 *    - the equinox of coordinates in the catalog
 *    - a set of passband-column pairs, of the form
 *                  U=4 B=5 V=3 
 *        which give the names of passbands in the catalog, plus the columns
 *        in which each passband is to be found
 *
 *  (optional args)
 *
 *    - a distance (in arcsec) defining the max distance two stars can
 *        be from one another and still count as a "match"
 *
 * Note that all column numbers should be supplied by the user in 1-indexed
 * form -- this, the first column of data in a file is "1", the second "2",
 * and so forth.  We subtract 1 to make the columns 0-indexed for internal
 * use.
 * 
 * we attempt to extract a simple photometric solution for stars in the
 * "raw" star file.  Here's how:
 *
 * 1. Run through the "raw" data file.  For each entry, extract (RA, Dec),
 *    plus all the raw magnitudes.  Convert (RA, Dec) to J2000.
 *
 * 2. Run through the catalog.  For each entry, extract (RA, Dec),
 *    plus all the known magnitudes.  Convert (RA, Dec) to J2000.
 *
 * 3. For each catalog star (we assume there are fewer catalog stars than
 *    "raw" stars), 
 *
 *      3a. seek the matching "raw" star.  If no match, go to step 3.
 * 
 *      3b. Compare the magnitude(s) of the "raw" star with those of the 
 *          catalog star.  Calculate the difference in each matching passband.
 *
 * 4. Calculate the mean difference and standard deviation from the mean
 *    for each matching passband.
 *
 * 5. Print the results to stdout.
 *
 *
 *
 * Usage: photom_match starfile1 racol deccol equinox v=3 ... \
 *                     catalog   racol deccol equinox v=4 ... \
 *                     [radius=]
 *
 * </HTML>
 * </AUTO>
 *
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "precess.h"
#include "misc.h"
#include "photom_match.h"


#undef DEBUG           /* get some of diagnostic output */

typedef int (*PFI)();

static int
read_mstar_file(char *file, int racol, int deccol, double equinox, int nband,
               int *magcol, int *num_star, struct s_mstar **star_array);

static int
find_matching_pairs(int raw_nstar, struct s_mstar *raw_array, 
                    int cat_nstar, struct s_mstar *cat_array,
                    double radius, int *nmatch, int **raw_match_index,
                    int **cat_match_index);

static int
compare_ra(struct s_mstar *star1, struct s_mstar *star2);

static int
find_first_index(double start_ra, int raw_nstar, struct s_mstar *raw_array);

static int
find_closest_index(struct s_mstar *cat_star, int raw_nstar,
              struct s_mstar *raw_array, int start_index, double radius);

static void analyze_matched_pairs(int raw_nstar, struct s_mstar *raw_array,
                                  int raw_nband, char *raw_passband,
                                  int cat_nstar, struct s_mstar *cat_array,
                                  int cat_nband, char *cat_passband,
                                  int nmatch, int *raw_match_index,
                                  int *cat_match_index, FILE *fp);




#define USAGE  "usage: photom_match starfile1 racol deccol equinox v=3 ...\n"\
               "                    catalog   racol deccol equinox v=4 ..."
char *progname = "photom_match";



int
main
   (
   int argc,
   char *argv[]
   )
{ 
   char raw_file[50], cat_file[50];
   char outfile[50];
   char letter;
   char raw_passband[MAX_PASSBANDS], cat_passband[MAX_PASSBANDS];
   int i, first, last;
   int raw_racol, raw_deccol, cat_racol, cat_deccol;
   int raw_nband, cat_nband;
   int raw_nstar, cat_nstar;
   int number;
   int raw_magcol[MAX_PASSBANDS], cat_magcol[MAX_PASSBANDS];
   int nmatch;
   int *raw_match_index, *cat_match_index;
   double raw_equinox, cat_equinox;
   double match_radius = MATCH_RADIUS;
   struct s_mstar *raw_array, *cat_array;
   FILE *fp;

   if (argc < 11) {
      fprintf(stderr, "%s\n", USAGE);
      exit(1);
   }

   fp = stdout;

   /* parse the arguments */

   /* we start with those pertaining to the "raw" starlist file */
   strcpy(raw_file, argv[1]);
   if (sscanf(argv[2], "%d", &raw_racol) != 1) {
      shFatal("invalid argument for column for RA values in raw file");
   }
   if (sscanf(argv[3], "%d", &raw_deccol) != 1) {
      shFatal("invalid argument for column for Dec values in raw file");
   }
   if (sscanf(argv[4], "%lf", &raw_equinox) != 1) {
      shFatal("invalid argument for raw equinox");
   }
#ifdef DEBUG
   printf(" raw     file %20s has RA %2d, Dec %2d, equinox %4.0f\n",
	    raw_file, raw_racol, raw_deccol, raw_equinox);
#endif

   /* 
    * this is a little tricky.  We run through the args starting with #5,
    * checking for form like "U=4".  We'll set 'first' to the first occurence
    * (which ought to be 5) and 'last' to the last _consecutive_ occurence.
    * So, given args (starting with number 5)
    *
    *     arg    5   6   7    8     9 10  11  12  13
    *           U=4 B=5 V=6 landolt 3  4 1985 U=7 B=8
    *
    * we would set 'first' = 5 and 'last' = 7.
    */
   first = 5;
   last = argc - 1;
   for (i = first; i < argc; i++) {
      if (sscanf(argv[i], "%c=%d", &letter, &number) != 2) {
         if (i == first) {
	    shFatal("invalid argument for passband=column in raw file: %s",
		     argv[i]);
	 }
	 else {
	    last = i - 1;
	    break;
	 }
      }
   }
   if (last == argc - 1) {
      shFatal("%s", USAGE);
   }
   if (1 + (last - first) >= MAX_PASSBANDS) {
      shFatal("can only handle %d passbands in raw file", MAX_PASSBANDS);
   }
   raw_nband = 1 + last - first;
   for (i = first; i <= last; i++) {
      sscanf(argv[i], "%c=%d", 
	       &raw_passband[i - first], &raw_magcol[i - first]);
   }
#ifdef DEBUG
   for (i = 0; i < raw_nband; i++) {
      printf(" raw     passband %d has name %c, column %2d\n", i,
	       raw_passband[i], raw_magcol[i]);
   }
#endif

   /* 
    * now, starting with arg 'last + 1', we are up to the arguments 
    * pertaining to the catalog file 
    */
   strcpy(cat_file, argv[last + 1]);
   if (sscanf(argv[last + 2], "%d", &cat_racol) != 1) {
      shFatal("invalid argument for column for RA values in catalog file");
   }
   if (sscanf(argv[last + 3], "%d", &cat_deccol) != 1) {
      shFatal("invalid argument for column for Dec values in catalog file");
   }
   if (sscanf(argv[last + 4], "%lf", &cat_equinox) != 1) {
      shFatal("invalid argument for catalog equinox");
   }
#ifdef DEBUG
   printf(" catalog file %20s has RA %2d, Dec %2d, equinox %4.0f\n",
	    cat_file, cat_racol, cat_deccol, cat_equinox);
#endif

   /* 
    * Again we check to see how many consecutive arguments are of the
    * form "U=4".  We'll set 'first' to the first occurence
    * (which ought to be "last + 5") and re-set 'last' to the last 
    * _consecutive_ occurence.
    */
   first = last + 5;
   last = argc - 1;
   for (i = first; i < argc; i++) {
      if (sscanf(argv[i], "%c=%d", &letter, &number) != 2) {
         if (i == first) {
	    shFatal("invalid argument for passband=column in raw file: %s",
		     argv[i]);
	 }
	 else {
	    last = i - 1;
	    break;
	 }
      }
   }
   /* and now actually _read_ the catalog passbands and magnitude columns */
   if (1 + (last - first) >= MAX_PASSBANDS) {
      shFatal("can only handle %d passbands in catalog file", MAX_PASSBANDS);
   }
   cat_nband = 1 + last - first;
   for (i = first; i <= last; i++) {
      sscanf(argv[i], "%c=%d", 
	       &cat_passband[i - first], &cat_magcol[i - first]);
   }
#ifdef DEBUG
   for (i = 0; i < cat_nband; i++) {
      printf(" catalog passband %d has name %c, column %2d\n", i,
	       cat_passband[i], cat_magcol[i]);
   }
#endif

   /* 
    * check for optional arguments ....
    */
   for (i = last + 1; i < argc; i++) {
      if (strncmp(argv[i], "radius=", 7) == 0) {
         if (sscanf(argv[i] + 7, "%lf", &match_radius) != 1) {
            shFatal("invalid argument for radius argument");
         }
      }
      if (strncmp(argv[i], "outfile=", 8) == 0) {
         if (sscanf(argv[i] + 8, "%s", outfile) != 1) {
            shFatal("invalid argument for outfile argument");
         }
	 if ((fp = fopen(outfile, "w")) == NULL) {
	    shFatal("can't open file %s for output", outfile);
	 }
      }
   }

   /* 
    * convert "radius" value from arcseconds to degrees, for easier
    * comparison with calculated distances below 
    */
   match_radius /= 3600.0;

   /*
    * here, we subtract 1 from every "column" value, since from
    * here on, the code treats the first column as "0", the second as "1",
    * and so forth.
    */
   raw_racol--;
   raw_deccol--;
   for (i = 0; i < raw_nband; i++) {
      raw_magcol[i]--;
   }
   cat_racol--;
   cat_deccol--;
   for (i = 0; i < cat_nband; i++) {
      cat_magcol[i]--;
   }


   /* read in the information from the "raw" star file */
   if (read_mstar_file(raw_file, raw_racol, raw_deccol, raw_equinox,
		  raw_nband, raw_magcol, 
		  &raw_nstar, &raw_array) != SH_SUCCESS) {
      shFatal("error reading raw star file %s", raw_file);
   }
#ifdef DEBUG
   printf(" raw star list %s contains %d stars\n", raw_file, raw_nstar);
#endif

   /* read the information from the "catalog" star file */
   if (read_mstar_file(cat_file, cat_racol, cat_deccol, cat_equinox,
		  cat_nband, cat_magcol, 
		  &cat_nstar, &cat_array) != SH_SUCCESS) {
      shFatal("error reading catalog star file %s", cat_file);
   }
#ifdef DEBUG
   printf(" catalog star list %s contains %d stars\n", cat_file, cat_nstar);
#endif


   /*
    * Okay, now that we have the two arrays, we search for stars in the
    * CATALOG which match those in the RAW file.  For each match, we 
    * fill in the "raw_match" and "cat_match" elements with the positions
    * of the matching stars.
    */
   if (find_matching_pairs(raw_nstar, raw_array, cat_nstar, cat_array,
                           match_radius, &nmatch, 
                           &raw_match_index, &cat_match_index) != 0) {
      shFatal("error in find_matching_pairs");
   }

   /*
    * finally, we analyze the matched pairs, sending the output
    * to stdout (or "outfile", if one was specified).
    */
   analyze_matched_pairs(raw_nstar, raw_array, raw_nband, raw_passband,
                         cat_nstar, cat_array, cat_nband, cat_passband,
			 nmatch, raw_match_index, cat_match_index, fp);


   if (fp != stdout) {
      fclose(fp);
   }

   /* may as well free the arrays we've allocated */
   shFree(raw_array);
   shFree(cat_array);
   shFree(raw_match_index);
   shFree(cat_match_index);

   return(0);
}



/****************************************************************************
 * ROUTINE: read_mstar_file
 *
 * walk through the given file, one line at a time.  
 *
 * If the line starts with COMMENT_CHAR, skip it.
 * If the line is completely blank, skip it.
 *
 * Otherwise, 
 *   - create a new "s_mstar" structure
 *   - read in the entire line  
 *   - figure out the "RA" and "Dec" coords
 *   - convert (RA, Dec) to J2000 (if necessary)
 *   - each of the "nband" values in the "magcol" array gives the column
 *        in which a magnitude value appears; read that magnitude value,
 *        and fill the appropriate element in the "s_mstar" structure
 *
 * Place the total number of stars read into the "nstar" argument, 
 * and place a pointer to the array of "nstar" structures in the
 * "star_array" argument.
 *
 * RETURNS:
 *   SH_SUCCESS            if all goes well
 *   SH_GENERIC_ERROR      if not
 */

static int
read_mstar_file
   (
   char *file,              /* I: name of input file with star list */
   int racol,               /* I: position of column with RA positions */
   int deccol,              /* I: position of column with Dec positions */
   double equinox,          /* I: equinox of positions in this file */
   int nband,               /* I: number of magnitude measurements per star */
   int *magcol,             /* I: array giving column for each magnitude */
   int *num_star,           /* O: number of stars in file (and output array) */
   struct s_mstar **star_array 
                            /* O: pointer to newly-created array of stars */
   )
{
   char line[LINELEN];
   char col[MAX_DATA_COL + 1][MAX_COL_LENGTH + 1];
   int nline, nbytes;
   int i, ncol;
   int skip;
   int last_column;
   int nstar;
   double ra, dec, new_ra, new_dec;
   struct s_mstar *array;
   FILE *fp;

   if ((fp = fopen(file, "r")) == NULL) {
      shError("read_mstar_file: can't open file %s for input", file);
      return(SH_GENERIC_ERROR);
   }

   /*
    * figure out the last column which holds data of interest
    */
   last_column = 0;
   last_column = (racol > last_column ? racol : last_column);
   last_column = (deccol > last_column ? deccol : last_column);
   for (i = 0; i < nband; i++) {
      last_column = (magcol[i] > last_column ? magcol[i] : last_column);
   }

   /* 
    * first, we run through the file to count the number of lines with data 
    */
   nline = 0;
   while (fgets(line, LINELEN, fp) != NULL) {
      if (line[0] == COMMENT_CHAR) {
	 continue;
      }
      if (is_blank(line)) {
	 continue;
      }
      nline++;
   }

   /* 
    * create a big array of "nline" s_mstar structures
    */
   nbytes = nline*sizeof(struct s_mstar);
   array = (struct s_mstar *) shMalloc(nbytes);

   /*
    * okay, now we have to re-read the file, filling in each s_mstar
    * structure as we go 
    */
   rewind(fp);
   nstar = 0;
   while (fgets(line, LINELEN, fp) != NULL) {
      if (line[0] == COMMENT_CHAR) {
	 continue;
      }
      if (is_blank(line)) {
	 continue;
      }

      ncol = sscanf(line, "%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s", 
              &(col[0][0]), &(col[1][0]), &(col[2][0]), &(col[3][0]), 
              &(col[4][0]), &(col[5][0]), &(col[6][0]), &(col[7][0]), 
              &(col[8][0]), &(col[9][0]), &(col[10][0]), &(col[11][0]),
              &(col[12][0]), &(col[13][0]), &(col[14][0]), &(col[15][0]),
              &(col[16][0]), &(col[17][0]), &(col[18][0]), &(col[19][0]));

      if (last_column > ncol) {
         shError("read_mstar_file: not enough entries in following line; skipping");
         shError("  %s", line);
         continue;
      }
        
      /* now read values from each column */
      if (get_value(col[racol], &ra) != SH_SUCCESS) {
         shError("read_mstar_file: can't read RA value from %s; skipping", 
                  col[racol]);
         continue;
      }
      if (get_value(col[deccol], &dec) != SH_SUCCESS) {
         shError("read_mstar_file: can't read Dec value from %s; skipping", 
                  col[deccol]);
         continue;
      }

      /*
       * if necessary, precess coords to J2000 
       */
      if (equinox != 2000.0) {
	 to_j2000(equinox, ra, dec, &new_ra, &new_dec);
	 ra = new_ra;
	 dec = new_dec;
      }

      array[nstar].ra = ra;
      array[nstar].dec = dec;

      /*
       * read each of the magnitudes from this line
       */
      skip = 0;
      for (i = 0; i < nband; i++) {
	 if (get_value(col[magcol[i]], &(array[nstar].mag[i])) != SH_SUCCESS) {
	    shError("read_mstar_file: can't read mag %d from %s; skipping",
		     i, col[magcol[i]]);
	    skip = 1;
	    break;
	 }
      }
      if (skip == 1) {
	 continue;
      }

#ifdef DEBUG
      printf(" star %4d: %9.4f %9.4f  ", nstar, ra, dec);
      for (i = 0; i < nband; i++) {
	 printf(" %6.3f", array[nstar].mag[i]);
      }
      printf("\n");
#endif

      /*
       * we've managed to read all the information for this star properly,
       * so let's make it official by incrementing the "nstar" counter 
       */

      nstar++;
      
   }

   /*
    * now set the output arguments
    */
   *num_star = nstar;
   *star_array = array;
   

   fclose(fp);
   return(SH_SUCCESS);
}



/****************************************************************************
 * ROUTINE: find_matching_pairs
 *
 * Go through the two arrays of stars, looking for matching items,
 * based on the positions.  Accept any match within "radius" degrees.
 *
 * The strategy is 
 *     - sort both arrays by RA
 *     - walk through CATALOG array.  For each star,
 *           look for match in RAW array 
 *
 * We create output arrays which are larger than they have to be,
 * but that's okay -- we're not short on memory...
 *
 * Place the total number of matching items read into the "nmatch" argument, 
 * and create two output arrays of ints with "nmatch" items in each.
 * Each output array stores the indices of matching elements.
 *
 * RETURNS:
 *   SH_SUCCESS            if all goes well
 *   SH_GENERIC_ERROR      if not
 */

static int
find_matching_pairs
   (
   int raw_nstar,              /* I: number of stars in raw array */
   struct s_mstar *raw_array,  /* I: array of "raw" stars */
   int cat_nstar,              /* I: number of stars in catalog array */
   struct s_mstar *cat_array,  /* I: array of "catalog" stars */
   double radius,              /* I: max dist for matching stars (degrees) */
   int *nmatch,                /* O: number of matching elements */
   int **raw_match_index,      /* O: we create this array with indices into */
                               /*       "raw_array" for matching elements */
   int **cat_match_index       /* O: we create this array with indices into */
                               /*       "cat_array" for matching elements */
   )
{
   int i, num_match;
   int *raw_index, *cat_index;
   int start_index, closest_index, other_index, index;
   double start_ra;
   double dra, ddec, dist, other_dist;
   struct s_mstar *raw_star;
   struct s_mstar *cat_star;

   /* 
    * first, create output arrays.  We'll make them larger than they need
    * to be, so that we can make a single pass in searching.
    */
   raw_index = (int *) shMalloc(raw_nstar*sizeof(int));
   cat_index = (int *) shMalloc(cat_nstar*sizeof(int));

   /*
    * now, sort both input arrays by RA 
    */
   qsort((void *) raw_array, raw_nstar, sizeof(struct s_mstar), 
	       (PFI) compare_ra);
   qsort((void *) cat_array, cat_nstar, sizeof(struct s_mstar), 
	       (PFI) compare_ra);

   /*
    * Now, we walk through the catalog array, dealing with one star at a time.
    * For each one, we make binary search for the "raw" star which
    * has an RA just less than (catalog RA - radius).  We can then march
    * forwards through the "raw" array looking for the closest match.
    */
   num_match = 0;
   for (i = 0; i < cat_nstar; i++) {
      cat_star = &(cat_array[i]);
      start_ra = cat_star->ra - radius;

      /*
       * There are three possible cases we have to check here:
       *     A: catalog RA very small     RA < radius
       *     B: catalog RA "normal"       RA > radius   and   RA < 360-radius
       *     C: catalog RA very big                           RA > 360-radius
       *
       * In case A, we have to make two searches for a match: one using
       * the catalog RA, and one using RA = (360 - catalog RA).  Then we pick
       * the better of the two matches (if there are two).
       *
       * In case B (the usual case), we need make only one search.
       *
       * In case C, we again have to make two searches: one using the
       * catalog RA, the other using RA = radius.  Then we pick the better
       * of the two matches.
       */

      other_index = -1;

      /* we make this search in all cases A, B, C */
      start_index = find_first_index(start_ra, raw_nstar, raw_array);
      closest_index = find_closest_index(cat_star, raw_nstar, raw_array, 
			   start_index, radius);

      /* 
       * now check to see if we have to make a second search; if so, 
       * we'll set "other_index" equal to the index of the star closest
       * to the other possibility for RA.
       */
      if (cat_star->ra < radius) {

	 /* case A: we need to check as if the star's RA were (360 - cat_ra) */
	 start_ra = (360.0 - cat_star->ra) - radius;
         start_index = find_first_index(start_ra, raw_nstar, raw_array);
         other_index = find_closest_index(cat_star, raw_nstar, raw_array, 
			   start_index, radius);

      } 
      else if (cat_star->ra > (360.0 - radius)) {

	 /* 
	  * case C: we need to check as if the star's RA were "radius",
	  * which means that start_ra = radius - radius = 0 */
	 start_ra = 0;
         start_index = find_first_index(start_ra, raw_nstar, raw_array);
         other_index = find_closest_index(cat_star, raw_nstar, raw_array, 
			   start_index, radius);

      }

      /* 
       * now, check to see if we found any possible matches.  If we found
       * more than 1, pick the star which is closer to the catalog star.
       */
      if ((closest_index != -1) && (other_index == -1)) {
	 index = closest_index;
      } 
      else if ((closest_index == -1) && (other_index != -1)) {
	 index = other_index;
      }
      else {
	 /* 
	  * must check to see which is a better match.  Calc distance
	  * to each candidate match in arcsec, and pick the one which is 
	  * closer.
	  */
	 raw_star = &(raw_array[closest_index]);
	 dra = (cat_star->ra - raw_star->ra)*cos(cat_star->dec*DEGTORAD);
	 ddec = (cat_star->dec - raw_star->dec);
	 dist = sqrt(dra*dra + ddec*ddec)*3600.0;
	 raw_star = &(raw_array[other_index]);
	 dra = (cat_star->ra - raw_star->ra)*cos(cat_star->dec*DEGTORAD);
	 ddec = (cat_star->dec - raw_star->dec);
	 other_dist = sqrt(dra*dra + ddec*ddec)*3600.0;
	 if (dist < other_dist) {
	    index = closest_index;
	 }
	 else {
	    index = other_index;
	 }
      }

      if (index == -1) {
#ifdef DEBUG
	 printf(" no match found for star %4d at (%10.5f, %10.5f)\n", 
		  i, cat_star->ra, cat_star->dec);
#endif
      }
      else {
#ifdef DEBUG
	    /* calculate distance in arcsec */
	    raw_star = &(raw_array[index]);
	    dra = (cat_star->ra - raw_star->ra)*cos(cat_star->dec*DEGTORAD);
	    ddec = (cat_star->dec - raw_star->dec);
	    dist = sqrt(dra*dra + ddec*ddec)*3600.0;
	    printf(" MATCH  %4d (%9.5f, %8.5f) = %4d (%9.5f, %8.5f)  dist %5.1f\n",
		  i, cat_star->ra, cat_star->dec, index, 
		  raw_star->ra, raw_star->dec, dist);
#endif
	 raw_index[num_match] = index;
	 cat_index[num_match] = i;
	 num_match++;
      }
   }

#ifdef DEBUG
   printf(" total of %d matches \n", num_match);
#endif

   *nmatch = num_match;
   *raw_match_index = raw_index;
   *cat_match_index = cat_index;

   return(SH_SUCCESS);
}



/****************************************************************************
 * ROUTINE: compare_ra
 *
 * Compare two s_mstar structures by RA.  
 *
 * Return
 *    1                  if first star has larger "RA"
 *    0                  if the two have equal "RA"
 *   -1                  if the first has smaller "RA"
 *
 */

static int
compare_ra
   (
   struct s_mstar *star1,          /* I: compare "ra" field of this star .. */
   struct s_mstar *star2           /* I:  ... with that of THIS star */
   )
{
   shAssert((star1 != NULL) && (star2 != NULL));

   if (star1->ra > star2->ra) {
      return(1);
   }
   if (star1->ra < star2->ra) {
      return(-1);
   }
   return(0);
}


/****************************************************************************
 * ROUTINE: find_first_index
 *
 * Given an array of "raw_nstar" raw star structures, which have already
 * been sorted in ascending order by RA, and given some value "ra",
 * return the index of the raw star which occurs JUST before
 * the given "ra" value.
 *
 * We use a binary search to find the desired index.
 *
 * If there is no such star, then return the index of the last raw star.
 *
 */

static int
find_first_index
   (
   double start_ra,              /* I: want star just before this RA */
   int raw_nstar,                /* I: there are this many raw stars in array */
   struct s_mstar *raw_array     /* I: array of raw stars, sorted by RA */
   )
{
   int top, bottom, mid;
   int retval;

   shAssert(raw_array != NULL);

#ifdef DEBUG
   printf("find_first_index: looking for RA = %.4f\n", start_ra);
#endif
   
   top = 0;
   if ((bottom = raw_nstar - 1) < 0) {
      bottom = 0;
   }

   while (bottom - top > 2) {
      mid = (top + bottom)/2;
#ifdef DEBUG
      printf(" array[%4d] RA=%.4f   array[%4d] RA=%.4f  array[%4d] RA=%.4f\n",
                  top, raw_array[top].ra, mid, raw_array[mid].ra,
                  bottom, raw_array[bottom].ra);
#endif
      if (raw_array[mid].ra > start_ra) {
         bottom = mid;
      }
      else {
         top = mid;
      }

   }
#ifdef DEBUG
      printf(" array[%4d] RA=%.4f                       array[%4d] RA=%.4f\n",
                  top, raw_array[top].ra, bottom, raw_array[bottom].ra);
#endif

   /*
    * if we get here, then the item we seek is either "top" or "bottom"
    * (which may point to the same item in the array).
    */
   if (raw_array[bottom].ra > start_ra) {
#ifdef DEBUG
      printf(" choosing  array[%4d] RA=%.4f \n", top, raw_array[top].ra);
#endif
      retval = top;
   }
   else {
#ifdef DEBUG
      printf(" choosing  array[%4d] RA=%.4f \n", bottom, raw_array[bottom].ra);
#endif
      retval = bottom;
   }

   /*
    * now, check to make sure that this item has RA < start_ra.  If not,
    * we try to back up in the raw_array until that's the case.  
    */
   while ((retval > 0) && (raw_array[retval].ra >= start_ra)) {
      retval--;
#ifdef DEBUG
      printf(" backing   array[%4d] RA=%.4f \n", retval, raw_array[retval].ra);
#endif
   }

#ifdef DEBUG
   printf(" return    array[%4d] RA=%.4f \n", retval, raw_array[retval].ra);
#endif

   return(retval);
}



/****************************************************************************
 * ROUTINE: find_closest_index
 *
 * Given a catalog s_mstar structure,  
 * an array of "raw_nstar" raw star structures, which have already
 * been sorted in ascending order by RA, 
 * an index into the "raw_array" at which to start looking, 
 * and a matching radius (in degrees), 
 * try to find the "raw" star which is closest to the given catalog star.
 *
 * If the closest "raw" star is within "radius" degrees, then it's a match;
 * if not, no match.
 *
 * RETURN:
 *    index of matching "raw" star      if there is one
 *    -1                                if no match
 *
 */

static int
find_closest_index
   (
   struct s_mstar *cat_star,     /* I: want to find a match to this star */
   int raw_nstar,                /* I: there are this many raw stars in array */
   struct s_mstar *raw_array,    /* I: array of raw stars, sorted by RA */
   int start_index,              /* I: start looking here in raw array */
   double radius                 /* I: max distance (degrees) for a match */
   )
{
   int i, closest;   
   double cat_ra, cat_dec, raw_ra, raw_dec;
   double dec_factor, max_ra, min_dist2;
   double dra, ddec, dist2;
   struct s_mstar *raw_star;

   shAssert(cat_star != NULL);
   shAssert(raw_array != NULL);

   cat_ra = cat_star->ra;
   cat_dec = cat_star->dec;
   dec_factor = cos(cat_dec*DEGTORAD);
   if (dec_factor <= 0.0) {
      shError("closest_index: can't handle Dec = 90 degrees");
      return(-1);
   }
   max_ra = cat_ra + (radius/dec_factor);
   min_dist2 = radius*radius;

   closest = -1;
   for (i = start_index; i < raw_nstar; i++) {
      raw_star = &(raw_array[i]);
      raw_ra = raw_star->ra;

      /* check to see if we can stop looking */
      if (raw_ra > max_ra) {
	 break;
      }

      raw_dec = raw_star->dec;
      dra = (cat_ra - raw_ra)*dec_factor;
      ddec = (cat_dec - raw_dec);
      dist2 = (dra*dra + ddec*ddec);
      if (dist2 < min_dist2) {
	 closest = i;
	 min_dist2 = dist2;
      }
   }

   return(closest);
}
      

/****************************************************************************
 * ROUTINE: analyze_matched_pairs
 *
 * Given an array of "raw_nstar" raw stars,
 *       an array of "cat_nstar" catalog stars,
 *       the number of matching stars,
 *       and indices into each array for the matching elements,
 *
 * do two things with the matched pairs:
 *
 *    1. calculate mean and stdev of differences between matched stars
 *            in "identical" passbands (i.e. "V" and "V", etc).
 *            Print out these statistics in lines which start with 
 *            COMMENT_CHAR characters
 *
 *    2. print a list of the matched stars, showing position, 
 *            difference in position (raw - catalog),
 *            and magnitudes in all defined passbands.
 *
 * However, do NOT include any magnitudes with value "BAD_MAG" in
 * the calculations -- they denote missing or invalid data.
 *
 * RETURN:
 *    nothing
 */

static void
analyze_matched_pairs
   (
   int raw_nstar,               /* I: number of stars in "raw" array */
   struct s_mstar *raw_array,   /* I: array of all "raw" star measurements */
   int raw_nband,               /* I: number "raw" passbands */
   char *raw_passband,          /* I: names of "raw" passbands */
   int cat_nstar,               /* I: number of stars in "catalog" array */
   struct s_mstar *cat_array,   /* I: array of all "catalog" stars */
   int cat_nband,               /* I: number "cat" passbands */
   char *cat_passband,          /* I: names of "cat" passbands */
   int nmatch,                  /* I: number of matched pairs of stars */
   int *raw_match_index,        /* I: index into "raw" array for matches */
   int *cat_match_index,        /* I: index into "catalog" array for matches */
   FILE *fp                     /* I: print results to this stream */
   )
{
   char matched_passband[MAX_PASSBANDS];   /* names passbands in common */
   int i, j;
   int nband;                   /* number of passbands in common */
   int raw_band_index[MAX_PASSBANDS], cat_band_index[MAX_PASSBANDS];
   int count[MAX_PASSBANDS];
   double dra, ddec, dist;
   double raw_mag, cat_mag, diff;
   double mean, stdev;
   double sum[MAX_PASSBANDS], sumsq[MAX_PASSBANDS];
   struct s_mstar *raw_star, *cat_star;

#ifdef DEBUG
   printf(" found a total of %d matching pairs ... \n", nmatch);
#endif

   /* identify the passbands the "raw" and "catalog" stars have in common */
   nband = 0;
   for (i = 0; i < raw_nband; i++) {
      for (j = 0; j < cat_nband; j++) {
	 if (raw_passband[i] == cat_passband[j]) {
	    matched_passband[nband] = raw_passband[i];
	    raw_band_index[nband] = i;
	    cat_band_index[nband] = j;
	    nband++;
	    break;
	 }
      }
   }
#ifdef DEBUG
   printf(" passbands in common are: \n");
   for (i = 0; i < nband; i++) {
      printf(" raw band %d = %c   equals cat band %d = %c\n",
	       raw_band_index[i], raw_passband[raw_band_index[i]],
	       cat_band_index[i], cat_passband[cat_band_index[i]]);
   }
#endif

   for (i = 0; i < nband; i++) {
      sum[i] = 0.0;
      sumsq[i] = 0.0;
      count[i] = 0;
   }

   /*
    * walk through the set of matched pairs, calculating statistics
    * as we go ...
    */
   for (i = 0; i < nmatch; i++) {
      raw_star = &(raw_array[raw_match_index[i]]);
      cat_star = &(cat_array[cat_match_index[i]]);
#ifdef DEBUG
      printf("raw star %4d vs. cat star %4d\n", raw_match_index[i],
		  cat_match_index[i]);
#endif

      /* calculate RA, Dec, and total distance between the stars (arcsec) */
      dra = (raw_star->ra - cat_star->ra)*cos(cat_star->dec*DEGTORAD)*3600.0;
      ddec = (raw_star->dec - cat_star->dec)*3600.0;
      dist = sqrt(dra*dra + ddec*ddec);
#ifdef DEBUG
      printf("   dra = %5.1f  ddec = %5.1f   dist = %5.1f\n", dra, ddec, dist);
#endif

      /* 
       * calc the difference between each corresponding magnitude, and
       * add to the growing sums 
       */
      for (j = 0; j < nband; j++) {
	 raw_mag = raw_star->mag[raw_band_index[j]];
	 cat_mag = cat_star->mag[cat_band_index[j]];
	 if ((raw_mag == BAD_MAG) || (cat_mag == BAD_MAG)) {
#ifdef DEBUG
      printf("   %c: raw %6.3f  cat %6.3f   skipping    \n", 
		     matched_passband[j], raw_mag, cat_mag);
#endif
	    continue;
	 }
	 diff = raw_mag - cat_mag;
#ifdef DEBUG
      printf("   %c: raw %6.3f  cat %6.3f   diff = %6.3f\n", 
		     matched_passband[j], raw_mag, cat_mag, diff);
#endif

	 sum[j] += diff;
	 sumsq[j] += diff*diff;
	 count[j]++;
      }
   }

   for (i = 0; i < nband; i++) {
      if (count[i] == 0) {
#ifdef DEBUG
         printf("no matches in band %c, so no stats\n", matched_passband[i]);
#endif
      }
      else {
         if (count[i] == 1) {
	    mean = sum[i];
	    stdev = 0.0;
	 } 
	 else {
	    mean = sum[i]/(double) count[i];
	    stdev = sqrt((sumsq[i] - nmatch*mean*mean)/(count[i] - 1.0));
	 }
	 printf("%c  passband %c  N %3d  mean %7.3f  stdev %7.3f \n", 
	       COMMENT_CHAR, matched_passband[i], count[i], mean, stdev);
      }
   }

   /* 
    * let's make a SECOND pass through the same set of matched pairs,
    * this time printing out one line per star with a nice format,
    * plus a nice header line giving labels for the columns.
    * We make a second pass so that the summary lines, above, will
    * be printed out first.
    */
   fprintf(fp, "%c \n", COMMENT_CHAR);
   fprintf(fp, "%c RA, Dec are in degrees, but dRA, dDec, dist in arcsec\n",
		     COMMENT_CHAR);
   fprintf(fp, "%c %10s %10s %5s %5s %5s", COMMENT_CHAR, "cat RA  ", 
                     "cat Dec  ", "dRA", "dDec", "dist");
   for (j = 0; j < raw_nband; j++) {
      fprintf(fp, "  raw %c", raw_passband[j]);
   }
   for (j = 0; j < cat_nband; j++) {
      fprintf(fp, "  cat %c", cat_passband[j]);
   }
   fprintf(fp, "\n");

   for (i = 0; i < nmatch; i++) {
      raw_star = &(raw_array[raw_match_index[i]]);
      cat_star = &(cat_array[cat_match_index[i]]);

      /* calculate RA, Dec, and total distance between the stars (arcsec) */
      dra = (raw_star->ra - cat_star->ra)*cos(cat_star->dec*DEGTORAD)*3600.0;
      ddec = (raw_star->dec - cat_star->dec)*3600.0;
      dist = sqrt(dra*dra + ddec*ddec);

      fprintf(fp, " %10.5f %10.5f  %5.1f %5.1f %5.1f ", cat_star->ra,
	       cat_star->dec, dra, ddec, dist);

      /* 
       * print out all the "raw" magnitudes first, then all the "catalog"
       * magnitudes
       */
      for (j = 0; j < raw_nband; j++) {
	 fprintf(fp, " %6.3f", raw_star->mag[j]);
      }
      for (j = 0; j < cat_nband; j++) {
	 fprintf(fp, " %6.3f", cat_star->mag[j]);
      }
    
      fprintf(fp, "\n");
   }

}
