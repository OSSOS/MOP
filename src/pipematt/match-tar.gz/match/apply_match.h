#if !defined(APPLY_MATCH_H)
#define APPLY_MATCH_H


   /* multiply by this to convert degrees to radians */
#ifndef PI
#define PI 3.14159265359
#endif
#define DEGTORAD  (PI/180.0)

#endif   /* APPLY_MATCH_H */
